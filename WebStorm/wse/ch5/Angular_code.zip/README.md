# WebStorm Essentials AngularJS

Sample code for the WebStorm Essentials AngularJS Example